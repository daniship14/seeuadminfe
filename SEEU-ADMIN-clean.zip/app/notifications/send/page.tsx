'use client';

import { useState } from 'react';
import axios from 'axios';
import AdminLayout from '@/components/layout/AdminLayout';

const PERSONAS = [
  'stable individuals',
  'sensory-oriented individuals',
  'new explorers',
];

const MESSAGE_TYPES = [
  { label: 'Welcome Message', value: 'welcome_msg' },
  { label: 'Subscription Message', value: 'subscription_msg' },
];

export default function SendNotificationPage() {
  const [persona_type, setPersonaType] = useState(PERSONAS[0]);
  const [msg_type, setMsgType] = useState('welcome_msg');
  const [message, setMessage] = useState('');
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [isUrgent, setIsUrgent] = useState(false);

  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : '';

  const searchUsers = async (value: string) => {
    setSearch(value);
    if (!value) {
      setUsers([]);
      return;
    }
    try {
      const res = await axios.get(
        `https://seeu-api.prometteur.in/admin/users?search=${value}&page_size=10`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUsers(res.data?.data?.results || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSend = async () => {
    try {
      setLoading(true);
      await axios.post(
        'https://seeu-api.prometteur.in/admin/send-notification-to-users',
        { persona_type, msg_type, message, search },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Notification sent successfully');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <style>{`
        .notif-page {
          padding: 32px 40px;
          min-height: 100vh;
          color: #fff;
        }
        .notif-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 28px;
        }
        .notif-title {
          font-size: 22px;
          font-weight: 600;
          color: #fff;
          margin: 0;
        }
        .back-link {
          display: flex;
          align-items: center;
          gap: 6px;
          color: #e05c7a;
          font-size: 14px;
          text-decoration: none;
          cursor: pointer;
          background: none;
          border: none;
        }
        .notif-card {
          background: #1e1535;
          border-radius: 16px;
          padding: 28px 32px 32px;
          max-width: 720px;
        }
        .card-heading {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 16px;
          font-weight: 600;
          color: #fff;
          padding-bottom: 18px;
          border-bottom: 1px solid rgba(255,255,255,0.08);
          margin-bottom: 24px;
        }
        .card-heading svg {
          color: #7c5cbf;
        }
        .section-label {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          font-weight: 600;
          color: #fff;
          margin-bottom: 16px;
        }
        .section-label svg {
          color: #e0963a;
        }
        .select-wrapper {
          position: relative;
          margin-bottom: 4px;
        }
        .floating-label {
          position: absolute;
          top: 10px;
          left: 14px;
          font-size: 10px;
          font-weight: 500;
          color: rgba(255,255,255,0.45);
          text-transform: uppercase;
          letter-spacing: 0.5px;
          pointer-events: none;
        }
        .notif-select {
          background: #13102a;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 10px;
          color: #fff;
          font-size: 14px;
          padding: 28px 14px 10px 14px;
          width: 100%;
          box-sizing: border-box;
          outline: none;
          appearance: none;
          -webkit-appearance: none;
        }
        .notif-select:focus {
          border-color: rgba(124, 92, 191, 0.5);
        }
        .select-arrow {
          position: absolute;
          right: 14px;
          top: 50%;
          transform: translateY(-50%);
          pointer-events: none;
          color: rgba(255,255,255,0.4);
        }
        .validation-hint {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: rgba(255,255,255,0.35);
          margin-bottom: 14px;
          margin-top: 2px;
        }
        .validation-hint svg {
          color: rgba(255,255,255,0.35);
          flex-shrink: 0;
        }
        .send-to-label {
          font-size: 13px;
          font-weight: 500;
          color: #fff;
          margin-bottom: 8px;
        }
        .search-wrapper {
          position: relative;
          margin-bottom: 4px;
        }
        .search-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: rgba(255,255,255,0.3);
        }
        .search-input {
          background: #13102a;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 10px;
          color: #fff;
          font-size: 14px;
          padding: 12px 14px 12px 40px;
          width: 100%;
          box-sizing: border-box;
          outline: none;
        }
        .search-input::placeholder {
          color: rgba(255,255,255,0.3);
        }
        .search-input:focus {
          border-color: rgba(124, 92, 191, 0.5);
        }
        .search-dropdown {
          background: #1e1535;
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 10px;
          overflow: hidden;
          margin-top: 4px;
          z-index: 10;
          position: absolute;
          width: 100%;
        }
        .search-user-item {
          padding: 10px 14px;
          font-size: 13px;
          color: #fff;
          cursor: pointer;
          transition: background 0.15s;
        }
        .search-user-item:hover {
          background: rgba(124, 92, 191, 0.2);
        }
        .all-users-tag {
          font-size: 13px;
          color: rgba(255,255,255,0.5);
          margin-top: 8px;
          padding: 0 2px;
        }
        .card-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 28px;
        }
        .urgent-check {
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          font-size: 13px;
          color: rgba(255,255,255,0.7);
        }
        .urgent-radio {
          width: 18px;
          height: 18px;
          border-radius: 50%;
          border: 2px solid rgba(255,255,255,0.3);
          background: transparent;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: border-color 0.2s;
        }
        .urgent-radio.active {
          border-color: #e05c7a;
        }
        .urgent-radio.active::after {
          content: '';
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #e05c7a;
        }
        .send-btn {
          background: linear-gradient(135deg, #c0736a 0%, #c06090 100%);
          border: none;
          border-radius: 24px;
          color: #fff;
          font-size: 14px;
          font-weight: 600;
          padding: 11px 44px;
          cursor: pointer;
          transition: opacity 0.2s;
        }
        .send-btn:hover { opacity: 0.9; }
        .send-btn:disabled { opacity: 0.6; cursor: not-allowed; }
      `}</style>

      <div className="notif-page">
        <div className="notif-header">
          <h1 className="notif-title">Notification &amp; Communication</h1>
          <button className="back-link" onClick={() => history.back()}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            Back to List
          </button>
        </div>

        <div className="notif-card">
          {/* Card heading */}
          <div className="card-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            Send Notification
          </div>

          {/* Section label */}
          <div className="section-label">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            Add Information
          </div>

          {/* Persona Type */}
          <div className="select-wrapper">
            <span className="floating-label">Persona Type</span>
            <select
              className="notif-select"
              value={persona_type}
              onChange={(e) => setPersonaType(e.target.value)}
            >
              {PERSONAS.map((item) => (
                <option key={item} value={item}>{item.toUpperCase()}</option>
              ))}
            </select>
            <span className="select-arrow">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
            </span>
          </div>
          <div className="validation-hint">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
            Looks good!
          </div>

          {/* Message Type */}
          <div className="select-wrapper">
            <span className="floating-label">Message Type</span>
            <select
              className="notif-select"
              value={msg_type}
              onChange={(e) => setMsgType(e.target.value)}
            >
              {MESSAGE_TYPES.map((item) => (
                <option key={item.value} value={item.value}>{item.label}</option>
              ))}
            </select>
            <span className="select-arrow">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
            </span>
          </div>
          <div className="validation-hint">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
            Select message type
          </div>

          {/* Send To */}
          <div className="send-to-label">Send To</div>
          <div style={{ position: 'relative' }}>
            <div className="search-wrapper">
              <span className="search-icon">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </span>
              <input
                className="search-input"
                placeholder="Search users by email or select 'All Users'..."
                value={search}
                onChange={(e) => searchUsers(e.target.value)}
              />
            </div>
            {users.length > 0 && (
              <div className="search-dropdown">
                {users.map((user: any) => (
                  <div
                    key={user.user_id}
                    className="search-user-item"
                    onClick={() => { setSearch(user.email); setUsers([]); }}
                  >
                    {user.full_name} ({user.email})
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="all-users-tag">All Users</div>

          {/* Footer */}
          <div className="card-footer">
            <div className="urgent-check" onClick={() => setIsUrgent(!isUrgent)}>
              <div className={`urgent-radio ${isUrgent ? 'active' : ''}`} />
              Urgent Notifications
            </div>
            <button className="send-btn" onClick={handleSend} disabled={loading}>
              {loading ? 'Sending...' : 'Send'}
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}